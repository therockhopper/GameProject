var manifest = [
    {
        src:"lib/assets.json",
        forSpritesheet:"assets"
    },
    {
        src:"lib/assets.png",
        id:"assets"
    }      
];