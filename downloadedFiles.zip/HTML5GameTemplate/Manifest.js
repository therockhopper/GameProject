var manifest = [
    {
        src:"lib/assets.json",
        forSpritesheet:"gameAssets"
    },
    {
        src:"lib/assets.png",
        id:"gameAssets"
    },

    {
        src:"lib/biplaneAssets.json",
        forSpritesheet:"biplaneAssets"
    },
    {
        src:"lib/biplaneAssets.png",
        id:"biplaneAssets"
    },

    {
        src:"lib/boing.ogg",
        id:"boing",
        data:4
    }
];